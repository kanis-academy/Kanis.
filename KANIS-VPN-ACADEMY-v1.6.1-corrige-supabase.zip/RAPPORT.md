# Rapport — KANIS VPN ACADEMY v1.6.0

## Implémenté
- Écran de démarrage (logo officiel `logo-192.png`, animation, barre de chargement, vérification de session), puis page d'accueil d'authentification. L'ancienne interface n'est plus accessible avant connexion.
- Inscription directe : Nom, e-mail, téléphone, mot de passe + confirmation, type Acheteur / Revendeur. `signUp` Supabase, profil créé par trigger SQL, session ouverte automatiquement. Doublons refusés, rôle admin impossible depuis le formulaire. Si Supabase ne renvoie pas de session (confirmation e-mail encore active), l'app l'indique, explique comment la désactiver et ne se déclare jamais connectée.
- Revendeur : prix d'activation en haut du formulaire (promotion automatique incluse), compte inactif, page d'activation obligatoire (Orange Money / Wave, historique, vérification automatique toutes les 10 s), passage à ACTIF uniquement après confirmation serveur.
- Redirection selon rôle et statut à chaque ouverture ; déconnexion ; mot de passe oublié avec lien profond `kanisvpn://auth-callback` (page « nouveau mot de passe », message clair si lien expiré/invalide).
- Tableaux de bord acheteur (7 onglets), revendeur (7 onglets), administrateur (12 onglets dont Acheteurs, Revendeurs, Prix, Commissions).
- Migration `003` : trigger de profil robuste, `ensure_profile`, activation idempotente + index uniques, promotion d'activation appliquée côté serveur, blocage des ventes/commissions pour revendeur inactif.
- `supabase.js` embarqué dans l'APK (plus de CDN), plugin `@capacitor/app`, script `patch-android.js`, workflow mis à jour.

## Tests réellement effectués (Chromium sans interface, client Supabase SIMULÉ : 34/34 OK)
Première ouverture ; inscription acheteur sans e-mail + connexion automatique ; doublon ; mots de passe différents ; inscription revendeur (prix en haut du formulaire, profil « pending », page d'activation sans bouton de fermeture) ; demande de paiement ; compte toujours inactif avant confirmation ; activation → espace revendeur ; reconnexion revendeur inactif ; connexion acheteur / mauvais mot de passe / admin ; déconnexion ; réouverture (session restaurée) ; mot de passe oublié (redirection = `kanisvpn://auth-callback`, jamais localhost) ; lien profond de récupération valide et expiré ; détection de la confirmation e-mail encore active ; balayage des 26 onglets ; aucune erreur JavaScript.

## NON testé (honnêteté)
- **Aucun appel réel à Supabase** : les scénarios ci-dessus utilisent un faux client. Les migrations SQL (dont `003`) n'ont **jamais été exécutées** (pas de PostgreSQL ici) : exécute 001, 002, 003 et signale-moi toute erreur.
- Désactivation de « Confirm email » : réglage du tableau de bord Supabase, impossible depuis le code (instructions dans le README).
- Compilation Android / APK, lien profond sur téléphone, notifications, e-mails de récupération : non testés (pas de SDK Android ni de réseau).
- Aucune API Orange Money / Wave n'est branchée : la confirmation se fait par l'administrateur (ou par le webhook signé, à connecter).

## Corrections appliquées dans cette révision
- URL Supabase corrigée pour viser le projet `qoxsvtzjqprwzegbsnhv` (la clé publique déjà fournie est conservée).
- L’inscription transmet maintenant une URL de retour explicite : lien profond Android sur APK, origine de l’application sur le Web.
- La configuration de récupération de mot de passe laisse le Web utiliser son origine au lieu de forcer le schéma Android.

## Point à vérifier
`www/js/config.js` et `supabase/config.toml` pointent maintenant vers le projet `qoxsvtzjqprwzegbsnhv`, celui dont l’URL et la clé publique ont été communiquées dans la conversation et dans lequel les tables ont été préparées. L’inscription et la récupération de mot de passe utilisent le lien profond `kanisvpn://auth-callback` sur Android ; elles n’envoient plus l’utilisateur vers `localhost`.
