// Copie supabase.js (version figée) dans www/js/vendor : l'APK ne dépend plus d'un CDN.
const fs=require("fs"),path=require("path");
const src=path.join(__dirname,"..","node_modules","@supabase","supabase-js","dist","umd","supabase.js");
const dst=path.join(__dirname,"..","www","js","vendor","supabase.js");
if(!fs.existsSync(src)){console.error("supabase.js introuvable : lance d'abord « npm install ».");process.exit(1);}
fs.mkdirSync(path.dirname(dst),{recursive:true});fs.copyFileSync(src,dst);
console.log("OK www/js/vendor/supabase.js ("+fs.statSync(dst).size+" octets)");
