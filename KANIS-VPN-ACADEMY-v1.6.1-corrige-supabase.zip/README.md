# KANIS VPN ACADEMY – Application Android (v1.6.0)

Application Capacitor : le site est en HTML, CSS et JavaScript simples (`www/index.html`), sans React ni étape de compilation web.


## Version 1.6.0 — Vraie application : démarrage, connexion, inscription directe, activation revendeur

**Parcours** : écran de démarrage (logo, animation, chargement, vérification de la session) → page d'accueil (CRÉER UN COMPTE / SE CONNECTER / Mot de passe oublié) → espace selon le rôle :

| Utilisateur | Destination |
|---|---|
| Acheteur | Espace acheteur (Formations, Vidéos, Achats, Paiements, Codes, Alertes, Profil) |
| Revendeur actif | Espace revendeur (Accueil/solde, Vendre, Ventes, Clients, Codes, Historique, Profil) |
| Revendeur inactif | Page d'activation **obligatoire** (3 000 FCFA, ou prix promo), sans bouton pour la fermer |
| Administrateur | Administration (Stats, Acheteurs, Revendeurs, Formations, Vidéos, Prix, Promotions, Paiements, Commissions, Codes, Notifications, Réglages) |

Le bouton « ▶ Accéder aux formations et outils » ouvre l'ancienne interface (formations, vidéos, recherche IP, alertes, thèmes, paramètres), qui reste intacte mais n'est plus visible avant connexion.

### Configuration Supabase (à faire une seule fois)

1. **SQL Editor** : exécute dans l'ordre `001_kanis_schema.sql`, `002_notifications_roles.sql`, puis **`003_direct_signup_activation.sql`**.
2. **Inscription sans e-mail de confirmation** : Authentication → *Sign In / Providers* → *Email* → désactive **Confirm email** → Save. Laisse *Allow new users to sign up* activé. (Le code détecte le cas contraire : il n'affiche jamais « connecté » sans session et montre ces instructions.)
3. **Authentication → URL Configuration** : *Site URL* = `kanisvpn://auth-callback` et ajoute `kanisvpn://auth-callback` dans *Redirect URLs* (sinon le lien de récupération ne rouvre pas l'application).
4. **`www/js/config.js`** : l'URL et la clé publique (`sb_publishable_…`) doivent venir du **même** projet (Project Settings → API). Jamais la clé `service_role`.
5. **Premier administrateur** (seule façon d'en créer un) : crée ton compte dans l'app, puis dans le SQL Editor : `update public.profiles set role='admin' where email='TON_EMAIL';`
6. **Protection contre les abus** : Supabase limite déjà les inscriptions et connexions (Authentication → Rate Limits). Pour la production, active aussi la protection anti-robots (Authentication → Attack Protection) et configure un SMTP personnalisé : l'e-mail de récupération du mot de passe est limité avec le SMTP par défaut.

### Activation des revendeurs

Inscription Revendeur → le prix (ex. « ACTIVATION DU COMPTE REVENDEUR 3 000 FCFA ») s'affiche en haut du formulaire → compte créé en statut **inactif** → page d'activation → choix Orange Money ou Wave → commande « en attente ». Le compte ne devient **actif que lorsque le serveur confirme le paiement** : l'administrateur (Administration → Paiements → *Confirmer*, avec la référence de transaction) ou la fonction `payment-webhook` signée. Une seule demande d'activation en attente par compte, une seule activation confirmée (index SQL), et la promotion d'activation de l'administrateur est appliquée automatiquement (même système de promotions). Un revendeur inactif ne peut ni créer de vente, ni générer de codes, ni recevoir de commission (contrôlé en SQL).

### Compiler l'APK

Envoie **tout le contenu du ZIP** à la racine d'un dépôt GitHub (dossier caché `.github` compris) → onglet *Actions* → « Build KANIS VPN ACADEMY APK » → *Run workflow* → télécharge l'artifact `KANIS-VPN-ACADEMY-APK`. Le workflow installe `supabase.js` en local (plus de CDN), ajoute le lien profond `kanisvpn://auth-callback` au manifeste Android et vérifie sa présence avant de compiler. En local : `npm install`, `npm run android:add`, `npm run assets`, `npm run sync`, `npm run build:apk`.


## Version 1.5.0 / 1.4.0 — Comptes, tableaux de bord et serveur Supabase

Le projet existant (design, pages, formations, notifications, recherche d'IP) est conservé. Ajouts :

- `supabase/migrations/001_kanis_schema.sql` : tables, règles RLS, prix et promotions calculés côté serveur, commissions 90 % / 10 % créditées **uniquement à la confirmation réelle du paiement**, codes d'accès uniques (stockés hachés SHA-256, jamais en clair), remboursements.
- `www/js/kanis-backend.js` : connexion, inscription (prix d'activation revendeur 3 000 FCFA affiché, promotion appliquée automatiquement), mot de passe oublié/réinitialisation, espaces **acheteur**, **revendeur** et **administrateur** (menu ☰ → « Mon compte »).
- `supabase/functions/payment-webhook` : modèle de confirmation signée pour Orange Money / Wave (à brancher plus tard).
- Les anciens codes d'accès en clair ont été **retirés** de `index.html`.
- Logo officiel mis à jour : `www/img/` et `resources/` (icône, icône adaptative, écrans de démarrage).

### Mise en route (10 minutes)
1. Crée un projet sur supabase.com. SQL Editor → colle et exécute `001_kanis_schema.sql`.
2. Crée ton compte dans l'app, puis dans le SQL Editor : `update public.profiles set role='admin' where email='TON_EMAIL';` (c'est la seule façon de devenir admin).
3. Authentication → URL Configuration : renseigne le Site URL / Redirect URL pour le lien de réinitialisation.
4. L'URL est déjà dans `www/js/config.js` ; colle ta clé `sb_publishable_…` dans `anonKey` (jamais service_role). Voir aussi `RAPPORT.md`. Fichier : `www/js/config.js` (jamais la clé service_role).
5. Connecte-toi en admin → Vidéos : ajoute les chapitres et vidéos ; Promotions : crées-y toutes les promotions (activation revendeur incluse).
6. `npm run sync`, puis compile.

### Paiements (honnêteté)
Aucun fournisseur n'est connecté : chaque commande reste « en attente de vérification » jusqu'à ce que l'administrateur confirme (avec la référence de transaction) dans Administration → Paiements. Aucune transaction n'est jamais simulée.

### Reste à faire (partie 2 / suites)
Lien profond Android pour la réinitialisation du mot de passe, notifications push Firebase, API Orange Money/Wave réelles, protection anti-capture des vidéos, et conformité Google Play (facturation).

## Version 1.3.0 — Nouveau logo officiel + compilation GitHub

- Le **nouveau logo** remplace l'ancien partout : barre du haut, accueil, menu ☰, page « À propos », zone formations, icône du site. Il n'est plus découpé en cercle : il garde ses proportions (carré arrondi) et s'affiche sur fond clair comme sur fond sombre. Les anciens fichiers `logo.jpg` / `logo-192.jpg` sont supprimés.
- **Icône Android et écran de démarrage** : générés depuis le logo (`resources/`), version claire et version nuit.
- **Compilation automatique** : `.github/workflows/build.yml` crée le projet Android, génère les icônes, compile et publie `KANIS-VPN-ACADEMY.apk` dans les *Artifacts* de GitHub Actions.

### Obtenir l'APK
1. Envoie **tout le contenu de ce ZIP** à la racine d'un dépôt GitHub (dossier caché `.github` compris).
2. Onglet **Actions** → « Build KANIS VPN ACADEMY APK » → **Run workflow**.
3. À la fin, ouvre l'exécution → **Artifacts** → télécharge **KANIS-VPN-ACADEMY-APK**.

L'APK est signé avec la clé de débogage (installation directe). Pour publier sur le Play Store, utilise la signature décrite plus bas (`keystore.properties`).

## Contenu du projet

| Fichier | Rôle |
|---|---|
| `www/index.html` | Toute l'application : accueil, formations et paiement, formation vidéo, recherche d'IP, notifications, réglages |
| `www/img/` | Nouveau logo officiel (`logo.png`, `logo-192.png`, coins transparents) |
| `resources/` | Icône Android et écran de démarrage créés à partir de ton logo |
| `capacitor.config.json` | Nom de l'app et identifiant `com.kanis.vpnacademy` |
| `package.json` | Dépendances et commandes |
| `scripts/apply-signing.js` | Ajoute la signature de publication au projet Android |
| `keystore.properties.example` | Modèle du fichier de clé de signature |

## Nouveautés de la version 1.2.0

- **Le VPN a été retiré** (page, onglet, plugin Android). Il n'y a plus de code VPN dans le projet.
- **Mode clair et mode nuit corrigés** : toute l'interface change vraiment (barres, cartes, paiement). Le mode « Auto » suit le téléphone.
- **Couleur de l'interface au choix** : 8 couleurs (Or, Vert, Bleu, Rouge, Violet, Turquoise, Rose, Orange), à tout moment, dans le menu ☰ ou dans Paramètres. Elles marchent avec le mode clair et le mode nuit. Les tons sont plus doux pour les yeux.
- **Menu hamburger ☰ à gauche** (à la place des trois points).
- **Icônes du bas personnalisées** (Accueil, Formations, IP, Alertes).
- **Recherche d'IP améliorée** : champ avec icône, bouton « Mon IP », exemples, recherches récentes, résultats par carte avec drapeau.
- **Formations dans l'application** : plus de pages séparées. Voir plus bas.

## Formations : paiement, lien d'accès, vidéo dans l'application

1. Le client appuie sur **« Commencer la formation »**. S'il n'a pas payé, un message lui dit de **payer la formation pour recevoir son lien de formation**, avec un bouton qui l'amène au paiement.
2. Tu vérifies son paiement Orange Money (comme avant), puis tu lui envoies son **lien d'accès** sur WhatsApp.
3. Quand il ouvre le lien, il arrive **directement dans le site** : la formation se débloque et la **vidéo apparaît dans la page**. L'accès est mémorisé sur son téléphone.

### Comment fabriquer un lien d'accès

Le lien est : `adresse du site` + `#acces-` + `un code`.
Exemple : `https://claude.ai/artifact/CUfetF6VoGRRB2inxYA9x6#acces-dt-Ab3x9K`

Les codes sont dans le bloc `CONFIG` en haut du script de `www/index.html` :

```js
access: {
  "dark-tunnel":    ["dt-Ab3x9K", "dt-Qm7p2Z", "dt-Hs4n8W"],
  "bkcbebe-tunnel": ["bk-Lw8n4R", "bk-Tz5c1V", "bk-Jd6y3F"]
}
```

- Utilise **un code différent par client** (lettres, chiffres et tiret, sans espace).
- Pour retirer l'accès à quelqu'un, supprime son code de la liste puis republie.
- Le client peut aussi taper son code dans « J'ai déjà mon code d'accès ».
- **Change ces codes d'exemple avant de vendre.**

### Mettre les vidéos

Dans `CONFIG.videos`, colle un lien YouTube (vidéo « Non répertoriée ») ou un lien direct `.mp4` :

```js
videos: { "dark-tunnel": "https://youtu.be/XXXXXXXXXXX", "bkcbebe-tunnel": "https://youtu.be/YYYYYYYYYYY" }
```

Tant que le champ est vide, la page affiche « Vidéo bientôt disponible ». Si le lecteur YouTube refuse de s'afficher dans l'app, un bouton « Ouvrir la vidéo » est prévu.

### Limite importante

Il n'y a pas de serveur : les codes sont dans le code de la page. **Quelqu'un qui reçoit un lien peut le transmettre**, et un utilisateur avancé peut lire les codes. Pour une vraie protection (un compte par client, accès retiré à distance), il faut un serveur ou un service d'abonnement.

## 1. Ce qu'il faut installer (une seule fois)

- **Node.js 20 ou plus** : https://nodejs.org
- **Android Studio** (avec le SDK Android) : https://developer.android.com/studio
- **JDK 21** (installé avec Android Studio)

## 2. Installer le projet

```bash
npm install
npm run android:add     # crée le dossier android/
npm run assets          # génère les icônes et l'écran de démarrage
npm run sync            # copie www/ dans l'app (installe aussi le plugin de notifications)
```

## 3. Générer l'APK pour tester

```bash
npm run build:apk
```

Fichier créé : `android/app/build/outputs/apk/debug/app-debug.apk`. Sous Windows, si `./gradlew` ne marche pas, lance `gradlew.bat assembleDebug` dans le dossier `android/`. Envoie l'APK sur ton téléphone et autorise « Installer des applications inconnues », ou utilise `npm run open` puis ▶ dans Android Studio.

## 4. Clé de signature (une seule fois)

```bash
keytool -genkeypair -v -keystore kanis-release.jks -alias kanis -keyalg RSA -keysize 2048 -validity 10000
```

Place `kanis-release.jks` dans `android/app/`, copie `keystore.properties.example` vers `android/keystore.properties` et remplis les mots de passe. **Sauvegarde cette clé à plusieurs endroits** : sans elle, plus de mise à jour possible. Ne la publie jamais.

## 5. AAB signé pour Google Play

```bash
npm run build:aab
```

Fichier créé : `android/app/build/outputs/bundle/release/app-release.aab`. Si le script de signature échoue, ajoute un bloc `signingConfigs` à la main dans `android/app/build.gradle`.

## 6. Publier sur Google Play

1. Crée un compte développeur Google Play, puis l'app dans la Play Console et envoie l'**AAB** (active Play App Signing).
2. Remplis la fiche : description, captures, icône 512×512, politique de confidentialité, sécurité des données, classification.
3. Les nouveaux comptes personnels doivent souvent faire un test fermé avec des testeurs avant la production : vérifie la règle actuelle.
4. Pour chaque mise à jour, augmente `versionCode` et `versionName` dans `android/app/build.gradle`, puis refais `npm run build:aab`.

Risques à connaître :
- **Paiements** : Google exige en général son système de facturation pour vendre du contenu numérique dans une app. Ton paiement par Orange Money, hors Google Play, peut faire **refuser l'app**.
- **App qui n'est qu'un site** : peut aussi être refusée.
- **Politique de confidentialité obligatoire** (le site demande un nom et un numéro).

## Recherche d'IP

Aucune clé API ni serveur : l'app interroge **DNS Google** (secours Cloudflare) pour les domaines et le nom d'hôte d'une IPv4, et **ipwho.is** (secours **ipapi.co**) pour le pays, la ville, l'opérateur et l'ASN. Le bouton « Mon IP » affiche ton adresse publique. Ces services gratuits ont des limites : pour beaucoup d'utilisateurs, prends une offre avec clé API (ipinfo.io, par exemple) et change l'URL dans la fonction `ipInfo`. En cas d'échec réseau, l'app affiche un message clair et ne simule jamais un résultat.

## Notifications

**Locales (déjà configurées)** : plugin `@capacitor/local-notifications`, avec demande d'autorisation Android 13+. Nouveautés (tableau `NEWS` en haut du script), rappel quotidien à l'heure choisie, notification de test. Elles partent du téléphone seulement.

**À distance (non configurées)** : il faut Firebase Cloud Messaging.
1. Crée un projet sur https://console.firebase.google.com et ajoute une app Android `com.kanis.vpnacademy`.
2. Mets `google-services.json` dans `android/app/`.
3. `npm install @capacitor/push-notifications` puis `npm run sync`.
4. Dans `www/index.html`, appelle `Capacitor.Plugins.PushNotifications.requestPermissions()` puis `register()` et récupère le jeton (événement `registration`).
5. Envoie les messages depuis la console Firebase (menu « Messaging »).

N'ajoute le plugin qu'une fois `google-services.json` en place, sinon l'app plantera. Le suivi de commande demande un serveur.

## À tester sur ton téléphone

- Bouton « Payer 2 500 FCFA maintenant » : ouvre le clavier avec `*144*2*1*44947055*2500#`.
- Bouton WhatsApp : message avec le nom et la formation.
- Lien d'accès : la formation se débloque et la vidéo s'affiche.
- Recherche d'IP avec Internet, puis sans Internet.
- Notifications : autorisation, test.
- Modes clair et nuit, 8 couleurs, marges en haut et en bas.

## Modifier l'application

Modifie `www/index.html`, puis `npm run sync` et refais l'APK ou l'AAB.


## Configuration du projet Supabase utilisé
Cette version est configurée pour `https://qoxsvtzjqprwzegbsnhv.supabase.co`. La clé publique configurée doit appartenir à ce même projet. Sur Android, les liens d’authentification reviennent via `kanisvpn://auth-callback` ; configure cette URL dans Supabase Authentication → URL Configuration → Redirect URLs si la confirmation e-mail est utilisée. Pour une inscription sans validation e-mail, désactive aussi Confirm email dans les paramètres du fournisseur Email.
